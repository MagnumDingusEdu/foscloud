create function calculate_lineage() returns trigger
    language plpgsql
as
$$
DECLARE
    p_depth   integer;
    p_lineage varchar;
BEGIN
    IF NEW.parent_id <> OLD.parent_id THEN

        SELECT depth, lineage INTO p_depth, p_lineage FROM nodes WHERE id = NEW.parent_id;

        UPDATE nodes SET depth= p_depth + 1, lineage = p_lineage || NEW.id::varchar || '/' WHERE id = NEW.id;

    END IF;

    IF (TG_OP = 'INSERT') THEN
        SELECT depth, lineage INTO p_depth, p_lineage FROM nodes WHERE id = NEW.parent_id;

        UPDATE nodes SET depth= p_depth + 1, lineage = p_lineage || NEW.id::varchar || '/' WHERE id = NEW.id;

    END IF;

    RETURN NEW;
END
$$;

alter function calculate_lineage() owner to foscloud;

